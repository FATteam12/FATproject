package com.example.engineerManageSystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelReader;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.metadata.Sheet;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EngineerManageSystemApplicationTests {

	@Autowired
	private EngineerRepository repository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AdministratorRepository administratorRepository;

	private List<Engineer> createEngineerList() {
		List<Engineer> engineerList = repository.findAll();
		return engineerList;
	}

	@Test
	void contextLoads() throws Exception {
		OutputStream out = new FileOutputStream("D:/UserInfo.xlsx");
		ExcelWriter writer = EasyExcelFactory.getWriter(out);

		// 写仅有一个 Sheet 的 Excel 文件, 此场景较为通用
		Sheet sheet1 = new Sheet(1, 0, Engineer.class);

		// 第一个 sheet 名称
		sheet1.setSheetName("第一个sheet");

		// 写数据到 Writer 上下文中
		// 入参1: 创建要写入的模型数据
		// 入参2: 要写入的目标 sheet
		writer.write(createEngineerList(), sheet1);

		// 将上下文中的最终 outputStream 写入到指定文件中
		writer.finish();

		// 关闭流
		out.close();
	}
	@Test
	void readFile() throws Exception
	{
		InputStream inputStream = new FileInputStream("D:\\UserInfo.xlsx");
		AnalysisEventListener listener = new EngineerDataListener(repository);
		EasyExcelFactory.readBySax(inputStream, new Sheet(1,1,Engineer.class), listener);
	}

	@Test
	void insertUser()
	{
		for(int i=0;i<10;i++)
		{
			userRepository.save(new User("zcb"+i, "zcb"+i, "123"));
		}
	}

	@Test
	void insertAdminister()
	{
		administratorRepository.save(new Administrator("root","admin"));
	}
}
