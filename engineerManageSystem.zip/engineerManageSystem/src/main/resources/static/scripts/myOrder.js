﻿function addLoadEvent(func)
{
var oldonload=window.onload;
if(typeof window.onload!='function')
window.onload=func;
else 
{
window.onload=function()
{
oldonload();
func();
}
}
}
function insertAfter(newElement,targetElement)
{
var parent=targetElement.parentNode;
if(parent.lastChild==targetElement)
{
parent.appendChild(newElement);
}
else
{
parent.insertBefore(newElement,targetElement.nextSibling);
}
}

function addClass(element,value)
{
if(!element.className)
element.className=value;
else 
var NewClassName=element.className;
NewClassName+=" ";
NewClassName+=value;
element.className=NewClassName;
}

function fun(a,orderListItem,table)
{
	
	
	if(a.getAttribute("orderstatus")=='waitPay')
		a.onclick=function()
		{
		for(var i=0;i<table.length;i++)
		{
			table[i].style.display="none";
			var table2=table[i].getAttribute("title");
			var table3=table2.split("|");
			if(table3[1]!='yes')
				table[i].style.display="table";
		}
		}
	if(a.getAttribute("orderstatus")=='waitDelivery')
		a.onclick=function()
		{
		for(var i=0;i<table.length;i++)
		{
			table[i].style.display="none";
			var table2=table[i].getAttribute("title");
			var table3=table2.split("|");
			if(table3[0]!='yes')
				table[i].style.display="table";
		}
		}
	if(a.getAttribute("orderstatus")=='waitConfirm')
		a.onclick=function()
		{
		for(var i=0;i<table.length;i++)
		{
			table[i].style.display="none";
			var table2=table[i].getAttribute("title");
			var table3=table2.split("|");
			if(table3[0]=='yes')
				table[i].style.display="table";
		}
		}
	if(a.getAttribute("orderstatus")=='waitReview')
		a.onclick=function()
		{
		for(var i=0;i<table.length;i++)
		{
			table[i].style.display="none";
			var table2=table[i].getAttribute("title");
			var table3=table2.split("|");
			if(table3[2]=='0')
				table[i].style.display="table";
		}
		}
	
	
}

function selectMyOrder()
{
	var selectMyOrder=document.getElementById("selectMyOrder");
	var a=selectMyOrder.getElementsByTagName("a");
	var orderListItem=document.getElementById("orderListItem");
	var table=orderListItem.getElementsByTagName("table");
	
	for(var i=0;i<a.length;i++)
		{
			fun(a[i],orderListItem,table);		
		}
	
}

function shutDownThatFuckWindow()
{
	var closeTheDiv=document.getElementById("closeTheDiv");
	var moveDiv=document.getElementById("moveDiv");
	moveDiv.style.display="none";
	closeTheDiv.onclick=function()
	{
		moveDiv.style.display="none";
	}
	var orderListItem=document.getElementById("orderListItem");
	var td=orderListItem.getElementsByTagName("td");
	for (var i=0;i<td.length;i++)
		{
		if(td[i].getAttribute("title")=='jiayou')
			{
			var a=td[i].getElementsByTagName("a");
			
			a[0].onclick=function()
			{
				var orderId=this.getAttribute("title");
				var nmsl=document.getElementById("nmsl");
				nmsl.setAttribute("value",orderId);
				moveDiv.style.display="block";
			}
			}
			
		}
	
	
}
function checkDelete()
{
	var checkDelete=document.getElementById("orderListItem");
	var a=checkDelete.getElementsByTagName("a");
	for(var i=0;i<a.length;i++)
	{
		if(a[i].getAttribute("title")=="delete")
		{
			a[i].onclick=function()	
		
		{
		alert("删除该订单将损失所有的与该订单相关的信息！");
		var b=confirm("您确认删除该订单吗");
		if(!b)
		return false;		
	}
		}
		}
}

addLoadEvent(selectMyOrder);
addLoadEvent(shutDownThatFuckWindow);
addLoadEvent(checkDelete);