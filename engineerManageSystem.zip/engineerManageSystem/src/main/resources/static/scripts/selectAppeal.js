﻿m=new Map([['郑','Z'],['陈','C'],['彬','B'],['A','A']]);
function addLoadEvent(func)
{
var oldonload=window.onload;
if(typeof window.onload!='function')
window.onload=func;
else 
{
window.onload=function()
{
oldonload();
func();
}
}
}
function insertAfter(newElement,targetElement)
{
var parent=targetElement.parentNode;
if(parent.lastChild==targetElement)
{
parent.appendChild(newElement);
}
else
{
parent.insertBefore(newElement,targetElement.nextSibling);
}
}
function addClass(element,value)
{
if(!element.className)
element.className=value;
else 
var NewClassName=element.className;
NewClassName+=" ";
NewClassName+=value;
element.className=NewClassName;
}
function test()
{
var m=document.getElementsByTagName("ul");
var a=m[0].getElementsByTagName("li");
for(var i=1;i<a.length;i=i+2)
{
var c=a[i].getElementsByTagName("a");
for(var m=0;m<c.length;m++)
{
var c=a[i].getElementsByTagName("a");
c[m].oldClass=c[m].className;
}
a[i].onmouseover=function()
{
var c=this.getElementsByTagName("a");
var b=this.getElementsByTagName("ul");
addClass(c[0],"navClickStyle");
b[0].style.display="block";
}

a[i].onmouseout=function()
{
var b=this.getElementsByTagName("ul");
var c=this.getElementsByTagName("a");
c[0].className=c[0].oldClass;
b[0].style.display="none";
}

for(var t=1;t<c.length;t++)
{

c[t].onmouseover=function()
{
addClass(this,"navClickStylee");
}
c[t].onmouseout=function()
{
this.className=this.oldClass;
}

}
}
}
function check()
{
var a=document.getElementById("indicate");
var b=a.getElementsByTagName("a");
for(var i=0;i<b.length;i++)
{
b[i].oldClass=b[i].className;
b[i].onmouseover=function()
{
addClass(this,"clickStyle");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
}
}
function light()
{
var a=document.getElementById("sppagesize");
var b=a.getElementsByTagName("a");
var c=window.location.href;
for(var i=0;i<b.length;i++)
{
var d=b[i].getAttribute("href");
if(c.indexOf(d)>=0)
addClass(b[i],"lightYellow");
}

for(var i=0;i<b.length;i++)
{
b[i].onmouseover=function()
{
this.oldClass=this.className;
addClass(this,"lightYellow");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
}
}

function selectLight()
{
var a=document.getElementById("selectContentTab");
var b=a.getElementsByTagName("a");

for(var i=0;i<b.length;i++)
{
b[i].flag=i;
b[i].tex=b[i].lastChild.nodeValue;
b[i].onmouseover=function()
{
this.oldClass=this.className;
this.className="";
addClass(this,"specialLight");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
b[i].onclick=function()
{
var p=document.getElementById("selectContent");
var z=p.getElementsByTagName("li");
for(var w=0;w<z.length;w++)
{
z[w].style.display="block";
}
this.oldClass=this.className;
var m=document.getElementById("selectContentTab");
var n=m.getElementsByTagName("a");//a
for(var k=0;k<n.length;k++)
{
if(n[k].flag!=this.flag)
{
n[k].className="backStyle";
}
else 
{
addClass(this,"specialLight");
}
}

if(this.flag!==0)
for(var w=0;w<z.length;w++)
{
var a=z[w].getElementsByTagName("a");
var text=a[0].lastChild.nodeValue;
var text1=getPinYin(text[0]);
if(text1.indexOf(this.tex)==-1)
{
z[w].style.display="none";
}
}
}
b[0].style.width="55px";
b[0].style.height="20px";
}
}

function openTheSelect()
{
var a=document.getElementById("search1");
var b=document.getElementById("showCategory");
var c=a.getElementsByTagName("li");
for(var i=1;i<c.length;i=i+2)
{
c[i].flag=i;
c[i].onclick=function()
{
a.liNum=this.flag;
b.style.display="block";
var p=document.getElementById("selectContent");
var k=document.getElementById("search1");
var r=p.getElementsByTagName("div");
var t=document.getElementById("selectContentTab");
t.style.display="block";
for(var i=0;i<r.length;i++)
{
	r[i].style.display="block";
}
if(k.liNum==1)
{
for(var i=1;i<r.length;i++)
	r[i].style.display="none";
}
else if(k.liNum==3)
{
for(var i=0;i<r.length;i++)
	r[i].style.display="none";
r[1].style.display="block";
}
else if(k.liNum==5)
{
	for(var i=0;i<r.length;i++)
		r[i].style.display="none";
	r[2].style.display="block";
	r[3].style.display="block";
t.style.display="none";
}
else if(k.liNum==7)
{
	for(var i=0;i<r.length;i++)
		r[i].style.display="none";
	r[4].style.display="block";
	r[5].style.display="block";
t.style.display="none";
}
else if(k.liNum==9)
{
	for(var i=0;i<r.length;i++)
		r[i].style.display="none";
	r[6].style.display="block";
	r[7].style.display="block";
t.style.display="none";
}
}
}
var d=document.getElementById("shutDown");
var y=document.getElementById("shutDown1");
var c=document.getElementById("shutDown2");
var e=document.getElementById("shutDown3");
d.onclick=function()
{
b.style.display="none";
}
e.onclick=function()
{
b.style.display="none";
}
c.onclick=function()
{
b.style.display="none";
}
y.onclick=function()
{
b.style.display="none";
}
}
function selectLight2()
{
var a=document.getElementById("selectContent");
var b=a.getElementsByTagName("a");
for(var i=0;i<b.length;i++)
{
b[i].flag=i;
b[i].onmouseover=function()
{
this.oldClass=this.className;
this.className="";
addClass(this,"specialLight");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
b[i].onclick=function()
{
var k=document.getElementById("search1");
var u;
if(k.liNum==1)
{
	u=document.getElementById("s");
}
if(k.liNum==3)
{
	u=document.getElementById("d");
}
if(k.liNum==5)
	{
	u=document.getElementById("t");
	}
if(k.liNum==7)
{
u=document.getElementById("b");
}
if(k.liNum==9)
{
u=document.getElementById("y");
}
var span=u.getElementsByTagName("span");
span[0].lastChild.nodeValue=this.lastChild.nodeValue;
var b=document.getElementById("showCategory");
b.style.display="none";
}
}
}
function setWidth()
{
var a=document.getElementById ("orderTitle");
var b=a.getElementsByTagName("li");
var z=document.getElementById("orderList");
var c=z.getElementsByTagName("div");

for(var p=0;p<c.length;p=p+4)
{
var d=c[p].getElementsByTagName("div")

for(var i=0;i<b.length;i++)
{
if(i!=2)
{
d[i].style.width="27%";
}
else 
{
d[i].style.width="44%";
}
}
}
for(var i=0;i<b.length;i++)
{
if(i!=2)
{
b[i].style.width="27%";
}
else 
{
b[i].style.width="46%";
}
}

}
function myTest()
{
var a=document.getElementById("pageBox");
var b=a.getElementsByTagName("li");
for(var i=0;i<b.length;i++)
{
var c=b[i].getAttribute("class");
if(c=="disabled")
b[i].onclick=function()
{
return false;
}
}
}

function getPinYin(chinese)
{
if(!m.get(chinese))
{
return '?';
}
else
return m.get(chinese);
}
function fun1(a,b)
{
	var special=document.getElementById("orderId");
	if(special.getAttribute("value")=='' || special.getAttribute("value")==0)
		special.setAttribute("value",0);
	
	var s=document.getElementById(a);
	var sSpan=s.getElementsByTagName("span");
	var sSpanValue=sSpan[0].lastChild.nodeValue;
	if(b=="checkGetMoney")
	{
	if(sSpanValue=='确认到账')
		sSpanValue='yes';
	else if(sSpanValue=='仍未到账')
		sSpanValue='no';
	else 
		sSpanValue='unkonwn';
	}
	if(b=="checkSendProduct")
	{
	if(sSpanValue=='确认发货')
		sSpanValue='yes';
	else if(sSpanValue=='仍未发货')
		sSpanValue='no';
	else 
		sSpanValue='unkonwn';
	}
	if(sSpanValue=='未知')
		sSpanValue='';
	if(sSpanValue=='未知')
		sSpanValue='';
	if(sSpanValue=='小于100')
		{
		sSpanValue='100';		
		}
	if(sSpanValue=='小于500')
		{
		sSpanValue='500';
		}
	if(sSpanValue=='小于1000')
	{
	sSpanValue='1000';
	}
	if(sSpanValue=='小于2000')
	{
	sSpanValue='2000';
	}
	if(sSpanValue=='小于5000')
	{
	sSpanValue='5000';
	}

	var categoryName=document.getElementById(b);
	categoryName.setAttribute("value",sSpanValue);
}
function selectFormOnClick()
{
var selectForm=document.getElementById("selectForm");
selectForm.onsubmit=function()
{
	fun1("s","account");
	fun1("d","name");
	fun1("t","priceSum");
	fun1("y","commandevaluate");
	fun1("b","checkGetMoney");
	fun1("b","checkSendProduct");
}
}
function addLight()
{

var a=document.getElementById("pageBox");
var li=a.getElementsByTagName("a");
for(var i=0;i<li.length;i++)
	{
		
		li[i].onmouseover=function()
		{	
			this.oldClass=this.className;			
			addClass(this,"specialLight2");
		}
		li[i].onmouseout=function()
		{
		this.className=this.oldClass;
		}

	}
}
function checkDelete()
{
	var checkDelete=document.getElementById("checkDelete");
	checkDelete.onclick=function()
	{
		alert("删除该产品将损失所有的与该产品相关的信息！");
		var a=confirm("您确认删除该产品吗");
		if(!a)
		return false;
		
	}	
}
function changeColor()
{
	var orderList=document.getElementById("orderList");
	var li=orderList.getElementsByTagName("li");
	for(var i=0;i<li.length;i++)
		{
		li[i].onmouseover=function()
		{
		this.style.border="1px solid #00BFFF";
		}
		li[i].onmouseout=function()
		{
			this.style.border="1px solid #daf3ff";
		}
		}
}
function openThePriceSum()
{
	var myList=new Array();
	var myList2=new Array();
	var orderList=document.getElementById("orderList");
	var moveDiv=document.getElementById("moveDiv");
	var closeTheDiv=document.getElementById("closeTheDiv");
	var phone=document.getElementById("phone");
	var nmsl=document.getElementById("nmsl");
	var closeTheDiv2=document.getElementById("closeTheDiv2");
	var getSeed=document.getElementById("getSeed");
	var openTheDoor=document.getElementById("openTheDoor");
	openTheDoor.onclick=function()
	{
		getSeed.style.display="block";
	}
	closeTheDiv2.onclick=function()
	{
		getSeed.style.display="none";
	}
	closeTheDiv.onclick=function()
	{
		moveDiv.style.display="none";
	}
	
	var pricOperate=orderList.getElementsByTagName("span");
	for(var i=0;i<pricOperate.length;i++)
		{
		var priTitle=pricOperate[i].getAttribute("title");
		if(priTitle=="pric")
			{		
			var node=pricOperate[i].lastChild.nodeValue;	
			var b=node.split(":");
			myList.push(b[1]);
			}
		if(priTitle=="orderId")
		{
		var node=pricOperate[i].lastChild.nodeValue;	
		var b=node.split(":");
		myList2.push(b[1]);
		}
		}
	var m=0;
	var aOperate=orderList.getElementsByTagName("a");
	for(var i=0;i<aOperate.length;i++)
		{
		var title=aOperate[i].getAttribute("title")
		
		if(title=="titleKey")
			{
			aOperate[i].flag=m;
			m++;
			aOperate[i].onclick=function()
			{
				moveDiv.style.display="block";
				phone.setAttribute("value",myList[this.flag]);
				nmsl.setAttribute("value",myList2[this.flag]);
			}
			}
		}	
}
addLoadEvent(test);
addLoadEvent(check);
addLoadEvent(setWidth);
addLoadEvent(changeColor);
