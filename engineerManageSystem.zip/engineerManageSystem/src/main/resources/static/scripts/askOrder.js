function addLoadEvent(func)
{
var oldonload=window.onload;
if(typeof window.onload!='function')
window.onload=func;
else 
{
window.onload=function()
{
oldonload();
func();
}
}
}
function insertAfter(newElement,targetElement)
{
var parent=targetElement.parentNode;
if(parent.lastChild==targetElement)
{
parent.appendChild(newElement);
}
else
{
parent.insertBefore(newElement,targetElement.nextSibling);
}
}
function addClass(element,value)
{
if(!element.className)
element.className=value;
else 
var NewClassName=element.className;
NewClassName+=" ";
NewClassName+=value;
element.className=NewClassName;
}
function test()
{
var m=document.getElementsByTagName("ul");
var a=m[0].getElementsByTagName("li");
for(var i=1;i<a.length;i=i+2)
{
var c=a[i].getElementsByTagName("a");
for(var m=0;m<c.length;m++)
{
var c=a[i].getElementsByTagName("a");
c[m].oldClass=c[m].className;
}
a[i].onmouseover=function()
{
var c=this.getElementsByTagName("a");
var b=this.getElementsByTagName("ul");
addClass(c[0],"navClickStyle");
b[0].style.display="block";
}

a[i].onmouseout=function()
{
var b=this.getElementsByTagName("ul");
var c=this.getElementsByTagName("a");
c[0].className=c[0].oldClass;
b[0].style.display="none";
}

for(var t=1;t<c.length;t++)
{

c[t].onmouseover=function()
{
addClass(this,"navClickStylee");
}
c[t].onmouseout=function()
{
this.className=this.oldClass;
}

}
}
}
function check()
{
var a=document.getElementById("indicate");
var b=a.getElementsByTagName("a");
for(var i=0;i<b.length;i++)
{
b[i].oldClass=b[i].className;
b[i].onmouseover=function()
{
addClass(this,"clickStyle");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
}
}
function light()
{
alert(1);
var a=document.getElementById("sppagesize");
var b=a.getElementsByTagName("a");

var c=window.location.href;

for(var i=0;i<b.length;i++)
{
var d=b[i].getAttribute("href");
if(c.indexOf(d)>=0 || c.indexOf(d)>=0 || c.indexOf(d)>=0)
{
addClass(b[i],"lightYellow");
}
}
for(var i=0;i<b.length;i++)
{
b[i].onmouseover=function()
{
this.oldClass=this.className;
addClass(this,"lightYellow");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
}
}
function selectLight()
{
var a=document.getElementById("selectContentTab");
var b=a.getElementsByTagName("a");

for(var i=0;i<b.length;i++)
{
b[i].flag=i;
b[i].tex=b[i].lastChild.nodeValue;
b[i].onmouseover=function()
{
this.oldClass=this.className;
this.className="";
addClass(this,"specialLight");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
b[i].onclick=function()
{
var p=document.getElementById("selectContent");
var z=p.getElementsByTagName("li");
for(var w=0;w<z.length;w++)
{
z[w].style.display="block";
}
this.oldClass=this.className;
var m=document.getElementById("selectContentTab");
var n=m.getElementsByTagName("a");//a
for(var k=0;k<n.length;k++)
{
if(n[k].flag!=this.flag)
{
n[k].className="backStyle";
}
else 
{
addClass(this,"specialLight");
}
}

if(this.flag!==0)
for(var w=0;w<z.length;w++)
{
var a=z[w].getElementsByTagName("a");
var text=a[0].lastChild.nodeValue;

if(text.indexOf(this.tex)==-1)
{
z[w].style.display="none";
}
}
}
b[0].style.width="55px";
b[0].style.height="20px";
}
}

function openTheSelect()
{
var a=document.getElementById("search1");
var b=document.getElementById("showCategory");
var c=a.getElementsByTagName("li");
for(var i=1;i<c.length-2;i=i+2)
{
c[i].onclick=function()
{
b.style.display="block";
}
}
var d=document.getElementById("shutDown");
d.onclick=function()
{
b.style.display="none";
}
}
function selectLight2()
{
var a=document.getElementById("selectContent");
var b=a.getElementsByTagName("a");
for(var i=0;i<b.length;i++)
{
b[i].flag=i;
b[i].onmouseover=function()
{
this.oldClass=this.className;
this.className="";
addClass(this,"specialLight");
}
b[i].onmouseout=function()
{
this.className=this.oldClass;
}
b[i].onclick=function()
{
var u=document.getElementById("s");
var span=u.getElementsByTagName("span");
span[0].lastChild.nodeValue=this.lastChild.nodeValue;
var b=document.getElementById("showCategory");
b.style.display="none";
}
}
}
function setWidth()
{
var a=document.getElementById ("orderTitle");
var b=a.getElementsByTagName("li");
var c=document.getElementById("ner");
var d=c.getElementsByTagName("div")
for(var i=0;i<b.length;i++)
{
if(i!=1)
{
b[i].style.width="16%";
d[i].style.width="16%";
}
else 
{
b[i].style.width="35.08%";
d[i].style.width="35.08%";
}
}

}
function selectRadio()
{
var labelOne=document.getElementById("labelOne");
var inputOne=labelOne.getElementsByTagName("input");
var options=document.getElementById("options");
var label=options.getElementsByTagName("label");
for(var i=0;i<label.length;i++)
{
label[i].style.display="none";
}
for(var i=0;i<inputOne.length;i++)
{
var t=i;
inputOne[i].flag=t;
inputOne[i].onclick=function()
{

var options2=document.getElementById("options");
var label2=options.getElementsByTagName("label");
for(var i=0;i<label2.length;i++)
{
if(i==this.flag*2 || i==this.flag*2+1)
label2[i].style.display="block";
else
label2[i].style.display="none";
}
}
}
}
function checkDelete()
{
	var checkDelete=document.getElementById("checkDelete");
	checkDelete.onsubmit=function()
	{
		
		var a=confirm("您确认要提出申诉吗");
		if(!a)
		{
			
			return false;
		}
		else
			{
			alert("提出申诉成功");
			return true;
			}
		
	}	
}
addLoadEvent(test);
addLoadEvent(check);
addLoadEvent(selectRadio);
addLoadEvent(checkDelete);