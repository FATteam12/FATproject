﻿function addLoadEvent(func)
{
var oldonload=window.onload;
if(typeof window.onload!='function')
window.onload=func;
else 
{
window.onload=function()
{
oldonload();
func();
}
}
}
function insertAfter(newElement,targetElement)
{
var parent=targetElement.parentNode;
if(parent.lastChild==targetElement)
{
parent.appendChild(newElement);
}
else
{
parent.insertBefore(newElement,targetElement.nextSibling);
}
}
function addClass(element,value)
{
if(!element.className)
element.className=value;
else 
var NewClassName=element.className;
NewClassName+=" ";
NewClassName+=value;
element.className=NewClassName;
}

function createInputForm()
{
	
	
	
	var myCartTable=document.getElementById("test");
	myCartTable.onclick=function()
	{
		var aa=document.getElementById("submitTheForm");
		var inputDelete=aa.getElementsByTagName("input");
		
		for(var i=0;i<inputDelete.length;)
			{
			aa.removeChild(inputDelete[i]);
			}
		
		var a=document.getElementById("my-cart-table");
		var tbod=a.getElementsByTagName("tbody");
		var tbody=tbod[0];
		var tr=tbody.getElementsByTagName("tr");
		for(var i=0;i<tr.length-2;i++)
		{
			var td=tr[i].getElementsByTagName("td");
			var input1=document.createElement("input");
			var input2=document.createElement("input");
			var input3=document.createElement("input");
			var input4=document.createElement("input");
			input1.setAttribute("type","hidden");
			input2.setAttribute("type","hidden");
			input3.setAttribute("type","hidden");
			input4.setAttribute("type","hidden");
			var name="productsums["+i+"].name";
			var productId="productsums["+i+"].productId";
			var Numbers="productsums["+i+"].Numbers";
			var Univalent="productsums["+i+"].Univalent";
			var nameValue=td[1].lastChild.nodeValue;

			var productIdValue=tr[i].getAttribute("data-id");
			var number=td[3].getElementsByTagName("input");
			var NumbersValue=number[0].getAttribute("value");

			var q=td[2].lastChild.nodeValue;
			var w=q.split('$');
			
			var UnivalentValue=w[1];

			input1.setAttribute("name",name);
			input2.setAttribute("name",productId);
			input3.setAttribute("name",Numbers);
			input4.setAttribute("name",Univalent);
			
			input1.setAttribute("value",nameValue);
			input2.setAttribute("value",productIdValue);
			input3.setAttribute("value",NumbersValue);
			input4.setAttribute("value",UnivalentValue);
			var submitTheForm=document.getElementById("submitTheForm");
			submitTheForm.appendChild(input1);
			submitTheForm.appendChild(input2);
			submitTheForm.appendChild(input3);
			submitTheForm.appendChild(input4);
		}
	}
	
	//var tbod=myCartTable.getElementsByTagName("tbody");
	//var tbody=tbod[0];
	//var tr=tbody.getElementsByTagName("tr");
	//alert(tr.length)
	//for(var i=0;i<tr.length-2;i++)
	//{
	//	var a=tr[i].getAttribute("data-price");
	//	alert(a);
	//}
	
	
}


addLoadEvent(createInputForm);