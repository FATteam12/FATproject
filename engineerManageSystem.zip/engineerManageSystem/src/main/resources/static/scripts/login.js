﻿function addLoadEvent(func)
{
var oldonload=window.onload;
if(typeof window.onload!='function')
window.onload=func;
else 
{
window.onload=function()
{
oldonload();
func();
}
}
}
function insertAfter(newElement,targetElement)
{
var parent=targetElement.parentNode;
if(parent.lastChild==targetElement)
{
parent.appendChild(newElement);
}
else
{
parent.insertBefore(newElement,targetElement.nextSibling);
}
}
function addClass(element,value)
{
if(!element.className)
element.className=value;
else 
var NewClassName=element.className;
NewClassName+=" ";
NewClassName+=value;
element.className=NewClassName;
}
function forgetSecert()
{
	var login11=document.getElementById("login11");
	var registerFree=document.getElementById("registerFree");
	var shutDownTheWindow=document.getElementById("shutDownTheWindow");
	var createTheAccount=document.getElementById("createTheAccount");
	login11.style.display="none";
	registerFree.style.display="none";
	var forgetSerect=document.getElementById("forgetSerect");
	forgetSerect.onclick=function()
	{
		login11.style.display="block";
	}
	createTheAccount.onclick=function()
	{
		registerFree.style.display="block";
	}
	var closeTheDiv=document.getElementById("closeTheDiv");
	closeTheDiv.onclick=function()
	{
		login11.style.display="none";
	}
	shutDownTheWindow.onclick=function()
	{
		registerFree.style.display="none";
	}
}

addLoadEvent(forgetSecert);