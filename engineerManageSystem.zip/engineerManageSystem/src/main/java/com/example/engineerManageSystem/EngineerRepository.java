package com.example.engineerManageSystem;


import org.springframework.data.jpa.repository.JpaRepository;
import com.example.engineerManageSystem.Engineer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
// This will be AUTO IMPLEMENTED by Spring into a Bean called userRepository
// CRUD refers Create, Read, Update, Delete

@Transactional
@Repository
public interface EngineerRepository extends JpaRepository<Engineer, Integer> {

    //查询
    List<Engineer> findById(int id);
    List<Engineer> findByName(String name);
    List<Engineer> findAll();
    List<Engineer> findByIdAndName(int id,String name);
    //删除
    List<Engineer> deleteById(int id);
    List<Engineer> deleteByName(String name);



}