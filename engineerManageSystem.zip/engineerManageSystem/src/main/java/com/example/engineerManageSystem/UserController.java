package com.example.engineerManageSystem;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Controller
public class UserController {

    public static boolean isInteger(String str) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }
    
    private final UserRepository repository;
    private final OperationRepository operationRepository;
    private final orderRepository orderRepository;
    public static Boolean checkLegality(User user, List<String> errorList) 
    {
        String error = null;
        String name = user.getName();
        String password = user.getPassword();
        String username = user.getUsername();
        if(name.length()>20)
        {
            error = "姓名最长不超过20个字符";
        }
        if(name.equals(""))
        {
            error = "姓名不得为空";
        }
        if(password.length()>20)
        {
            error = "密码最长不超过20个字符";
        }
        if(password.equals(""))
        {
            error = "密码不得为空";
        }
        if(username.length()>20)
        {
            error = "用户名最长不超过20个字符";
        }
        if(username.equals(""))
        {
            error = "用户名不得为空";
        }
        if(error!=null)
        {
            errorList.add(error);
            return false;
        }
        return true;

    }
    UserController(UserRepository repository,OperationRepository operationRepository,orderRepository orderRepository) {
        this.repository = repository;
        this.operationRepository = operationRepository;
        this.orderRepository=orderRepository;
    }

    @GetMapping("/login")
    public String login()
    {
        return "login";
    }

    //显示所有用户
    @GetMapping("/showUser")
    public String showUser(Model model)
    {
        List<User> users = repository.findAll();
        System.out.print(users.size());
        model.addAttribute("users",users);
        return "showUser";
    }
    @GetMapping("/showUser1")
    public String showUser(@RequestParam(name = "id") String id, @RequestParam(name = "name") String name,
            Model model) {
        if(!isInteger(id))
        {
            String error = "ID应该为数字";
            model.addAttribute("error", error);
            return "selectEngineer";
        }
        List<User> users = new ArrayList<User>();
        if (id.equals("") && name.equals("")) {
            users = repository.findAll();
        }
        if (id.equals("") == false && name.equals("")) {
            int trans_id = Integer.parseInt(id);
            users = repository.findById(trans_id);
        }
        if (id.equals("") == false && name.equals("") == false) {
            int trans_id = Integer.parseInt(id);
            users = repository.findByIdAndName(trans_id, name);
        }
        if (id.equals("") && name.equals("") == false) {
            users = repository.findByName(name);
        }
        model.addAttribute("users", users);
        return "showUser";
    }
    //添加
    @GetMapping("/addUser")
    public String addUser(Model model)
    {
        model.addAttribute("user",new User());
        return "/addUser2";
    }
    @PostMapping("/addUser")
    public String addUser(@ModelAttribute User newUser, Model model)
    {
        System.out.println(newUser);
        ArrayList<String> myList = new ArrayList<String>();
        if(checkLegality(newUser,myList)==false)
        {
            model.addAttribute("error", myList.get(0));
            return "/addUser";
        }
        operationRepository.save(new Operation("添加","管理员"));
        repository.save(newUser);
        return "redirect:/showUser";
    }
    //根据id删除
    @RequestMapping("/deleteUser")
    public String deleteEngineer(@RequestParam(value="id") int id)
    {
        operationRepository.save(new Operation("删除","管理员"));
        repository.deleteById(id);
        return "redirect:/showUser";
    }

    @GetMapping("/ascUser")
    public String ascUser( Model model)
    {
        orderRepository.save(new Orders(1,"asc"));
        return "redirect:/showUser";
    }

    @GetMapping("/decUser")
    public String decUser( Model model)
    {
        orderRepository.save(new Orders(1,"dec"));
        return "redirect:/showUser";
    }

    //根据id修改
    @GetMapping("/updateUser")
    public String updateEngineer(@RequestParam(value="id") int id, Model model)
    {
        List<User> users = repository.findById(id);
        model.addAttribute("users",users);
        model.addAttribute("user",users.get(0));
        return "/updateUser";
    }
    //根据name修改
    @GetMapping("/updateUser2")
    public String updateEngineer(@RequestParam(value="name") String name, Model model)
    {
        List<User> users = repository.findByName(name);
        model.addAttribute("users",users);
        model.addAttribute("user",users.get(0));
        return "/updateUser";
    }
    @PostMapping("/updateUser1")
    public String updateEngineer1(@ModelAttribute User newUser, Model model)
    {
        operationRepository.save(new Operation("更新","管理员"));
        repository.save(newUser);
        return "redirect:/showUser";
    }

}