package com.example.engineerManageSystem;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@AllArgsConstructor
public class Administrator {

    private @Id @GeneratedValue(strategy = GenerationType.AUTO) @Column(columnDefinition = "INT(4)",nullable = false) Integer id;
    @Column(columnDefinition = "VARCHAR(20)",nullable = false)
    String adminpassword;  //密码
    @Column(columnDefinition = "VARCHAR(20)", nullable = false)
    String adminname;  //用户名
    Administrator()
    {

    }
    Administrator(String account,String password)
    {
        this.adminname = account;
        this.adminpassword = password;
    }
    public String getPassword(){
        return adminpassword;
    }
    public String getAdminname(){
        return adminname;
    }

}
