package com.example.engineerManageSystem;

import org.apache.catalina.startup.EngineRuleSet;
import org.springframework.data.domain.Sort;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Controller
public class EngineerController {

    private final EngineerRepository repository;
    private final OperationRepository operationRepository;
    private final orderRepository orderRepository;
    public static boolean isInteger(String str) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }

    public static Boolean checkLegality(Engineer engineer, List<String> errorList) {
        String error = null;
        int workAge = engineer.getWorkAge();
        String sex = engineer.getSex();
        double doubleSalary = engineer.getBasicSalary();
        String name = engineer.getName();
        String address = engineer.getAddress();
        String nativePlace = engineer.getNativePlace();
        String degree = engineer.getDegree();
        String telephone = engineer.getTelephone();
        if (telephone.equals("")) {
            error = "电话号码不能为空";
        }
        if (telephone.length() > 15) {
            error = "电话号码最长不超过15个字符";
        }
        if (!degree.equals("高中") && !degree.equals("学士") && !degree.equals("硕士") && !degree.equals("博士")
                && !degree.equals("其他")) {
            error = "选择高中、学士、硕士、博士、其它其中一项";
        }
        if (name.equals("")) {
            error = "姓名不得为空";
        }
        if (name.length() > 20) {
            error = "姓名长度不超过20个字符";
        }
        if (address.equals("")) {
            error = "地址不得为空";
        }
        if (address.length() > 30) {
            error = "地址长度不超过30个字符";
        }
        if (nativePlace.equals("")) {
            error = "籍贯不得为空";
        }
        if (nativePlace.length() > 10) {
            error = "籍贯长度不超过10个字符";
        }
        if (workAge > 50 ||  workAge < 0) {
            error = "工龄范围是(0,50]";
        }
        if (sex.equals("男") == false && sex.equals("女") == false) {
            error = "性别请选择男，女";
        }
        if (doubleSalary < 0) {
            error = "基本薪水需要大于0";
        }
        if (error != null) {
            errorList.add(error);
            return false;
        }
        return true;
    }

    EngineerController(EngineerRepository repository,OperationRepository repository2,orderRepository orderRepository) {
        this.repository = repository;
        this.operationRepository = repository2;
        this.orderRepository= orderRepository;
    }
    
    @GetMapping("/exportExcel")
    public String exportExcel(Model model) throws Exception
    {
        List<Engineer> engineerList = repository.findAll();
        Engineer.writeExcel(engineerList);
        return "redirect:/showEngineer";
    }
    @GetMapping("/importExcel")
    public String importExcel(Model model) throws Exception
    {
        Engineer.readFile(repository);
        return "redirect:/showEngineer";
    }


    @GetMapping("/showEngineer")
    public String showEngineer(Model model) {
        List<Engineer> engineers = repository.findAll();
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }

    @GetMapping("/showEngineer1")
    public String showEngineer(@RequestParam(name = "id") String id, @RequestParam(name = "name") String name,
            Model model) {
        if(!isInteger(id))
        {
            String error = "ID应该为数字";
            model.addAttribute("error", error);
            return "selectEngineer";
        }
        List<Engineer> engineers = new ArrayList<Engineer>();
        if (id.equals("") && name.equals("")) {
            engineers = repository.findAll();
        }
        if (id.equals("") == false && name.equals("")) {
            int trans_id = Integer.parseInt(id);
            engineers = repository.findById(trans_id);
        }
        if (id.equals("") == false && name.equals("") == false) {
            int trans_id = Integer.parseInt(id);
            engineers = repository.findByIdAndName(trans_id, name);
        }
        if (id.equals("") && name.equals("") == false) {
            engineers = repository.findByName(name);
        }
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }

    @GetMapping("/addEngineer")
    public String addEngineer(Model model) {
        model.addAttribute("engineer", new Engineer());
        return "/addEngineer2";
    }
    @PostMapping("/addEngineer")
    public String addEngineer(@ModelAttribute Engineer newEngineer, Model model) {
        List<String> errorList = new ArrayList<String>();
        if (checkLegality(newEngineer, errorList) == false) {
            model.addAttribute("error", errorList.get(0));
            return "/addEngineer2";
        }
        operationRepository.save(new Operation("添加","用户"+Engineer.Operator));
        repository.save(newEngineer);
        System.out.println(newEngineer);
        return "redirect:/showEngineer";
    }

    @RequestMapping("/deleteEngineer")
    public String deleteEngineer(@RequestParam(value = "id") int id) {
        operationRepository.save(new Operation("删除","用户"+Engineer.Operator));
        repository.deleteById(id);
        return "redirect:/showEngineer";
    }


    @GetMapping("/updateEngineer")
    public String updateEngineer(@RequestParam(value = "id") int id, Model model) {
        List<Engineer> engineers = repository.findById(id);
        model.addAttribute("engineer", engineers.get(0));
        return "/updateEngineer2";
    }

    @PostMapping("/updateEngineer")
    public String updateEngineer1(@ModelAttribute Engineer newEngineer, Model model) {
        operationRepository.save(new Operation("更新","用户"+Engineer.Operator));
        repository.save(newEngineer);
        return "redirect:/showEngineer";
    }

    @GetMapping("/sortEngineerById1")
    public String sortEngineerbyid1(Model model) {
        List<Orders> myOrder = orderRepository.findById(1);
        Sort sort =null;
        System.out.println(myOrder.get(0));
        if(myOrder==null || myOrder.get(0).getOrderStatus().equals("dec"))
        {
            Sort.Order oder = Sort.Order.desc("id");
            sort = Sort.by(oder);
        }
        else
        {
            Sort.Order oder = Sort.Order.asc("id");
            sort = Sort.by(oder);
        }
        List<Engineer> engineers = repository.findAll(sort);
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }


    @GetMapping("/sortEngineerByName1")
    public String sortEngineerByName1(Model model) {
        List<Orders> myOrder = orderRepository.findById(1);
        Sort sort =null;
        if(myOrder==null || myOrder.get(0).getOrderStatus().equals("dec"))
        {
            Sort.Order oder = Sort.Order.desc("name");
            sort = Sort.by(oder);
        }
        else
        {
            Sort.Order oder = Sort.Order.asc("name");
            sort = Sort.by(oder);
        }
        List<Engineer> engineers = repository.findAll(sort);
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }

    @GetMapping("/sortEngineerByWorkAge1")
    public String sortEngineerByWorkAge1(Model model) {
        List<Orders> myOrder = orderRepository.findById(1);
        Sort sort =null;
        if(myOrder==null || myOrder.get(0).getOrderStatus().equals("dec"))
        {
            Sort.Order oder = Sort.Order.desc("workAge");
            sort = Sort.by(oder);
        }
        else
        {
            Sort.Order oder = Sort.Order.asc("workAge");
            sort = Sort.by(oder);
        }
        List<Engineer> engineers = repository.findAll(sort);
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }

    @GetMapping("/salarySum")
    public String salarySum(Model model) {
        List<Engineer> engineers = repository.findAll();
        model.addAttribute("engineers", engineers);
        return "salarySum";
    }
    @GetMapping("/deleteAllEngineer")
    public String deleteAllEngineer(Model model)
    {
        repository.deleteAll();
        return "redirect:/showEngineer";
    }
    @GetMapping("/calculateSalary")
    public String CalculateSalary(Model model) {
        List<Engineer> engineers = repository.findAll();
        for(Engineer e:engineers)
        {
            e.setSalarySum();
        }
        model.addAttribute("engineers", engineers);
        return "selectEngineer";
    }
    @PostMapping("/CalculateSalary")
    public String CalculateSalary(@ModelAttribute Engineer newEngineer, Model model) {
        newEngineer.setSalarySum();
        repository.save(newEngineer);
        return "redirect:/salarySum";
    }
}