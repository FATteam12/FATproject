package com.example.engineerManageSystem;

import lombok.Data;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.*;

import org.springframework.data.annotation.CreatedDate;

@Data
@Entity
public class Operation {

    private @Id @GeneratedValue(strategy = GenerationType.AUTO) @Column(columnDefinition = "INT(4)") Integer id;
    @Column(columnDefinition = "VARCHAR(20)")
    private String operate_kind;

    @CreatedDate
    @Column(columnDefinition = "VARCHAR(30)")
    private String operate_date;

    @Column(columnDefinition = "VARCHAR(20)")
    private String person_kind;

    public Operation(String operate_kind,String person_kind)
    {
        SimpleDateFormat sim=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        this.operate_kind=operate_kind;
        this.operate_date = sim.format(new Date());
        this.person_kind=person_kind;
    }
}
