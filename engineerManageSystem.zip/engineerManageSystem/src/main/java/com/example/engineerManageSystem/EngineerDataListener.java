package com.example.engineerManageSystem;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Access;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;

import org.aspectj.apache.bcel.util.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.config.RepositoryBeanDefinitionRegistrarSupport;
import org.springframework.stereotype.Component;

@Component
public class EngineerDataListener extends AnalysisEventListener<Engineer>{

    List<Engineer> engineerList = new ArrayList<Engineer>();

    public EngineerRepository repository;

    public EngineerDataListener(EngineerRepository repository)
    {
        this.repository = repository;
    }
    @Override
    public void invoke(Engineer engineer,AnalysisContext analysisContext)
    {
        engineerList.add(engineer);
    }
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext)
    {
        repository.deleteAll();
        for(Engineer e:engineerList)
        {
            System.out.println(e);
            repository.save(e);
        }
        engineerList.clear();
    }

}