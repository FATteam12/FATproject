package com.example.engineerManageSystem;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.alibaba.excel.EasyExcelFactory;
import com.alibaba.excel.ExcelWriter;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.excel.metadata.BaseRowModel;
import com.alibaba.excel.metadata.Sheet;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.GenerationType;

@Data
@Entity
@AllArgsConstructor
@Builder
public class Engineer extends BaseRowModel{
    public static int Operator;
    @Id 
    @Column(columnDefinition = "int(4) zerofill") 
    @ExcelProperty(value="ID",index=0)
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "idOrGenerate") 
    @GenericGenerator(name = "idOrGenerate", strategy = "com.example.engineerManageSystem.IdOrGenerate")
    private Integer id;
    @Column(length = 20, nullable = false)
    @ExcelProperty(value="姓名",index=1)
    private String name;

    @Column(columnDefinition = "enum('男','女')")
    @ExcelProperty(value="性别",index=2)
    private String sex;

    @Temporal(TemporalType.DATE) @Column(columnDefinition = "DATE")
    @ExcelProperty(value="生日",index=3)
    private Date birth;

    @Column(length = 10, nullable = false)
    @ExcelProperty(value="籍贯",index=4)
    private String nativePlace;

    @Column(columnDefinition = "enum('高中','学士','硕士','博士','其他')")
    @ExcelProperty(value="学位",index=5)
    private String degree;

    @Column(length = 30,nullable = false) 
    @ExcelProperty(value="地址",index=6)
    private String address;

    @Column(length = 15)
    @ExcelProperty(value="电话",index=7)
    private String telephone;

    @Column(columnDefinition = "INT")
    @ExcelProperty(value="工龄",index=8)
    private int workAge;

    @Column(columnDefinition = "DOUBLE")
    @ExcelProperty(value="基本薪水",index=9)
    private double basicSalary;

    // 薪水＝（基本工资＋10*月有效工作日天数＋月效益*工作年限÷100）*0.9－月保险金。
    @ExcelProperty(value="保险金",index=10)
    private double salaryInsurance; // 保险金
    @ExcelProperty(value="月有效工作日天数",index=11)
    private int salaryDay; // 月有效工作日天数
    @ExcelProperty(value="月效益",index=12)
    private double salaryBenefit; // 月效益
    @ExcelProperty(value="总薪水",index=13)
    private double salarySum; // 总薪水

    public Engineer() {

    }

    public Engineer(String name, String sex, Date birth, String nativePlace, String degree, String address, String telephone,
            int workAge, double basicSalary) {
        this.name = name;
        this.sex = sex;
        this.birth = birth;
        this.nativePlace = nativePlace;
        this.degree = degree;
        this.address = address;
        this.telephone = telephone;
        this.workAge = workAge;
        this.basicSalary = basicSalary;
    }

    public Engineer(String name, String sex, Date birth, String nativePlace, String degree, String address, String telephone,
            int workAge, double basicSalary, double salary_Insurance, int salary_Day, double salary_Benefit) {
        this.name = name;
        this.sex = sex;
        this.birth = birth;
        this.nativePlace = nativePlace;
        this.degree = degree;
        this.address = address;
        this.telephone = telephone;
        this.workAge = workAge;
        this.basicSalary = basicSalary;
        this.salaryDay = salary_Day;
        this.salaryBenefit = salary_Benefit;
        this.salaryInsurance = salary_Insurance;

        // this.salary_Sum = (basicSalary + 10 * salary_Day + salary_Benefit * workAge
        // 100)*0.9 - salary_Insurance;
    }

    public Engineer(String name, String sex, String telephone, int workAge, double basicSalary) {
        this.name = name;
        this.sex = sex;
        this.telephone = telephone;
        this.workAge = workAge;
        this.basicSalary = basicSalary;
    }

    public void setSalarySum() {
        salarySum = (basicSalary + 10 * salaryDay + salaryBenefit * workAge / 100) * 0.9 - salaryInsurance;
    }

    public static void writeExcel(List<Engineer> EngineerList) throws Exception {
		OutputStream out = new FileOutputStream("D:/UserInfo.xlsx");
		ExcelWriter writer = EasyExcelFactory.getWriter(out);

		// 写仅有一个 Sheet 的 Excel 文件, 此场景较为通用
		Sheet sheet1 = new Sheet(1, 0, Engineer.class);

		// 第一个 sheet 名称
		sheet1.setSheetName("第一个sheet");

		// 写数据到 Writer 上下文中
		// 入参1: 创建要写入的模型数据
		// 入参2: 要写入的目标 sheet
		writer.write(EngineerList, sheet1);

		// 将上下文中的最终 outputStream 写入到指定文件中
		writer.finish();

		// 关闭流
		out.close();
    }
    public static void readFile(EngineerRepository repository) throws Exception
	{
		InputStream inputStream = new FileInputStream("D:\\UserInfo.xlsx");
		AnalysisEventListener listener = new EngineerDataListener(repository);
		EasyExcelFactory.readBySax(inputStream, new Sheet(1,1,Engineer.class), listener);
	}
    
}