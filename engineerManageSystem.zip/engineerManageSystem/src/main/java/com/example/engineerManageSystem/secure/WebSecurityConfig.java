package com.example.engineerManageSystem.secure;

import com.example.engineerManageSystem.Administrator;
import com.example.engineerManageSystem.AdministratorRepository;
import com.example.engineerManageSystem.Engineer;
import com.example.engineerManageSystem.User;
import com.example.engineerManageSystem.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private  UserRepository userRepository;

    @Autowired
    private AdministratorRepository administratorRepository;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                .antMatchers("/static/**").permitAll()
                .antMatchers("/showEngineer","/importExcel","/exportExcel").hasRole("USER")
                .antMatchers("/showUser").hasRole("ADMIN")
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login")
                .defaultSuccessUrl("/showEngineer")
                .permitAll()
                .and()
                .logout()
                .permitAll();
    }

    @Bean
    @Override
    public UserDetailsService userDetailsService() {
        return username -> {
            Administrator administrator = administratorRepository.findByAdminname(username);
            if(administrator!=null)
            {
                String password = administrator.getPassword();
                PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
                String passwordAfterEncoder = passwordEncoder.encode(password);
                return org.springframework.security.core.userdetails.User.withUsername(username).password(passwordAfterEncoder).roles("ADMIN").build();
            }
            else{
            User users = userRepository.findByUsername(username);
            if (users == null) {
                throw new UsernameNotFoundException("用户名未找到");
            }
            Engineer.Operator = users.getId();
            String password = users.getPassword();
            PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
            String passwordAfterEncoder = passwordEncoder.encode(password);
            return org.springframework.security.core.userdetails.User.withUsername(username).password(passwordAfterEncoder).roles("USER").build();
        }
        };
    }
}