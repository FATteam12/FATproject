package com.example.engineerManageSystem;

import com.example.engineerManageSystem.Engineer;
import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.engine.spi.SessionImplementor;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentityGenerator;
import java.io.Serializable;

public class IdOrGenerate extends IdentityGenerator {

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) throws MappingException {
        Object id = ((Engineer) object).getId();
        if (id != null) {
            return (Serializable) id;
        }
        return super.generate(session, object);
    }
}