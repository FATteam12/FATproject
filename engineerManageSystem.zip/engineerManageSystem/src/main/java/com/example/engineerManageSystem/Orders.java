package com.example.engineerManageSystem;

import lombok.Data;

import javax.persistence.*;


@Data
@Entity
public class Orders {
    @Id
    @Column(columnDefinition = "INT(4)") 
    private Integer id;
    @Column(columnDefinition = "VARCHAR(20)")

    private String orderStatus;
    public Orders(int id,String orderStatus)
    {
        this.id = id;
        this.orderStatus = orderStatus;
    }
    public Orders()
    {

    }
}