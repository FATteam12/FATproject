package com.example.engineerManageSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    //查询
    List<User> findById(int id);
    List<User> findByName(String account);
    User findByUsername(String account);
    List<User> findAll();
    List<User> findByIdAndName(int id,String name);
    //删除
    List<User> deleteById(int id);
    @Transactional
    List<User> deleteByName(String account);

}
