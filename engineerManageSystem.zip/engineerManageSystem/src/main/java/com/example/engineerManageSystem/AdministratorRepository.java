package com.example.engineerManageSystem;

import org.springframework.data.jpa.repository.JpaRepository;


public interface AdministratorRepository extends JpaRepository<Administrator, Integer> {
    Administrator findByAdminname(String account);
}
