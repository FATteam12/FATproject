package com.example.engineerManageSystem;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.metadata.BaseRowModel;

import javax.persistence.GenerationType;

@Data
@Entity
@AllArgsConstructor
@Builder
public class User extends BaseRowModel{
    
    private @Id @GeneratedValue(strategy = GenerationType.AUTO) @Column(columnDefinition = "INT(4)") Integer id;
    @Column(columnDefinition = "VARCHAR(20)", nullable = true)
    @ExcelProperty(value="姓名",index=0)
    private String name; // 姓名
    @Column(columnDefinition = "VARCHAR(20)", nullable = false)
    @ExcelProperty(value="密码",index=1)
    private String password; // 密码
    @Column(columnDefinition = "VARCHAR(20)", nullable = false)
    @ExcelProperty(value="年龄",index=2)
    private String username; // 用户名

    User() {

    }

    User(String name, String account, String password) {
        this.name = name;
        this.username = account;
        this.password = password;
    }
    User(String username,String password)
    {
        this.username = username;
        this.password = password;
    }
}